# Wajiha Adnan - Data Science Portfolio

React (Vite) + Tailwind v4 frontend, lightweight Flask backend. No database, no admin panel.

## Run locally (Windows)
Backend (terminal 1):
```
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python app.py
```
Frontend (terminal 2):
```
cd frontend
npm install
npm run dev
```
Open http://localhost:5173 (Vite proxies `/api` to Flask on port 5000).
Check: http://127.0.0.1:5000/api/health, then `npm run build` in `frontend`.

## Update content
- `frontend/src/data/portfolio.js`: profile links, about, experience, skills, education, **certifications**, activities.
- `frontend/src/data/projects.json`: projects (also served at `/api/projects`). Set `github` / `demo` to a URL or `null`.
- Resume: replace `frontend/public/resume.pdf`.
- Screenshots: add images to `frontend/public/` and extend `ProjectCard` to show them (not built yet).

## Contact form
Validated in the browser and on the server (length, email format, honeypot field, 5 messages/hour per IP). Messages are appended to `backend/messages.jsonl` (git-ignored). No email credentials are used.

## Deploy
Frontend: Netlify/Vercel (build `npm run build`, publish `dist`, set `VITE_API_URL` to the backend URL).
Backend: Render/Railway (`pip install gunicorn`, start `gunicorn app:app`, set `ALLOWED_ORIGINS` to the site URL). Note: free hosts may not keep `messages.jsonl`; add SMTP or a DB if you need durable storage.
