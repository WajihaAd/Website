import { useState } from 'react'
import { Github, Linkedin, Mail, Download, Menu, X, ArrowRight, ExternalLink, ChevronDown, Award } from 'lucide-react'
import { profile, nav, about, experience, skills, exposure, education, certifications, certNote, activities } from './data/portfolio'
import projects from './data/projects.json'

const API = import.meta.env.VITE_API_URL || ''
const card = 'rounded-2xl border border-white/10 bg-white/[0.03] p-6'
const btn = 'inline-flex items-center gap-2 rounded-xl px-5 py-3 text-sm font-semibold transition'
const primary = `${btn} bg-cyan-400 text-slate-900 hover:bg-cyan-300`
const ghost = `${btn} border border-white/20 text-white hover:bg-white/10`

const Section = ({ id, kicker, title, children }) => (
  <section id={id} className="scroll-mt-20 py-20">
    <div className="mx-auto max-w-6xl px-5">
      <p className="text-sm font-medium uppercase tracking-widest text-cyan-400">{kicker}</p>
      <h2 className="mb-10 mt-2 text-3xl font-semibold text-white sm:text-4xl">{title}</h2>
      {children}
    </div>
  </section>
)

function Header() {
  const [open, setOpen] = useState(false)
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-[#070f24]/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
        <a href="#home" className="text-lg font-semibold text-white">Wajiha<span className="text-cyan-400">.</span>Adnan</a>
        <nav aria-label="Main" className="hidden items-center gap-6 text-sm lg:flex">
          {nav.map(([l, id]) => <a key={id} href={`#${id}`} className="text-slate-300 hover:text-white">{l}</a>)}
          <a href={profile.resume} target="_blank" rel="noreferrer" className={`${primary} !py-2`}>Resume</a>
        </nav>
        <button className="lg:hidden" aria-label="Toggle menu" aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <nav aria-label="Mobile" className="flex flex-col gap-1 border-t border-white/10 px-5 pb-4 lg:hidden">
          {nav.map(([l, id]) => <a key={id} href={`#${id}`} onClick={() => setOpen(false)} className="py-2 text-slate-200">{l}</a>)}
          <a href={profile.resume} target="_blank" rel="noreferrer" className={`${primary} mt-2 justify-center`}>Resume</a>
        </nav>
      )}
    </header>
  )
}

function DashboardVisual() {
  const bars = [60, 95, 80, 130, 110, 160, 190]
  return (
    <svg viewBox="0 0 420 300" role="img" aria-label="Abstract analytics dashboard illustration" className="w-full max-w-md">
      <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#0f2a5e" /><stop offset="1" stopColor="#0a1636" /></linearGradient></defs>
      <rect x="4" y="4" width="412" height="292" rx="22" fill="url(#g)" stroke="#ffffff22" />
      {[0, 1, 2].map(i => <rect key={i} x={24 + i * 130} y="24" width="116" height="46" rx="10" fill="#ffffff0d" />)}
      {[0, 1, 2].map(i => <rect key={i} x={36 + i * 130} y="36" width="50" height="8" rx="4" fill="#22d3ee" opacity="0.7" />)}
      {[0, 1, 2].map(i => <rect key={i} x={36 + i * 130} y="52" width="80" height="6" rx="3" fill="#ffffff33" />)}
      {bars.map((h, i) => <rect key={i} x={32 + i * 52} y={270 - h} width="34" height={h} rx="6" fill="#38bdf8" opacity={0.25 + i * 0.1} />)}
      <polyline fill="none" stroke="#22d3ee" strokeWidth="3" strokeLinejoin="round" points={bars.map((h, i) => `${49 + i * 52},${255 - h}`).join(' ')} />
      {bars.map((h, i) => <circle key={i} cx={49 + i * 52} cy={255 - h} r="5" fill="#fff" stroke="#22d3ee" strokeWidth="2" />)}
    </svg>
  )
}

function Hero() {
  return (
    <section id="home" className="bg-[radial-gradient(ellipse_at_top_left,#12337a55,transparent_60%)] py-20 sm:py-28">
      <div className="mx-auto grid max-w-6xl items-center gap-12 px-5 lg:grid-cols-2">
        <div>
          <p className="mb-4 text-sm font-medium uppercase tracking-widest text-cyan-400">Data Science | Analytics | BI</p>
          <h1 className="text-4xl font-bold leading-tight text-white sm:text-5xl">{profile.headline}</h1>
          <p className="mt-6 max-w-xl text-lg text-slate-300">{profile.intro}</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#projects" className={primary}>Explore My Projects <ArrowRight size={16} /></a>
            <a href={profile.resume} target="_blank" rel="noreferrer" className={ghost}><Download size={16} /> View My Resume</a>
          </div>
          <div className="mt-6 flex gap-4 text-slate-300">
            <a href={profile.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn" className="hover:text-cyan-400"><Linkedin /></a>
            <a href={profile.github} target="_blank" rel="noreferrer" aria-label="GitHub" className="hover:text-cyan-400"><Github /></a>
            <a href={`mailto:${profile.email}`} aria-label="Email" className="hover:text-cyan-400"><Mail /></a>
          </div>
        </div>
        <div className="flex justify-center"><DashboardVisual /></div>
      </div>
    </section>
  )
}

function ProjectCard({ p }) {
  const [open, setOpen] = useState(false)
  return (
    <article className={`${card} flex flex-col`}>
      <p className="text-xs font-medium uppercase tracking-wider text-cyan-400">{p.category} | {p.status}</p>
      <h3 className="mt-2 text-xl font-semibold text-white">{p.title}</h3>
      <p className="mt-2 text-slate-300">{p.summary}</p>
      {p.metrics.length > 0 && (
        <ul className="mt-4 grid grid-cols-2 gap-2 text-sm">
          {p.metrics.map(m => <li key={m} className="rounded-lg bg-cyan-400/10 px-3 py-2 text-cyan-200">{m}</li>)}
        </ul>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        {p.tags.map(t => <span key={t} className="rounded-full border border-white/15 px-2.5 py-1 text-xs text-slate-300">{t}</span>)}
      </div>
      <button onClick={() => setOpen(!open)} aria-expanded={open} className="mt-4 flex items-center gap-1 self-start text-sm font-medium text-cyan-400">
        {open ? 'Hide details' : 'Details'} <ChevronDown size={16} className={open ? 'rotate-180' : ''} />
      </button>
      {open && (
        <dl className="mt-3 space-y-3 text-sm text-slate-300">
          <div><dt className="font-semibold text-white">Problem</dt><dd>{p.problem}</dd></div>
          <div><dt className="font-semibold text-white">My role</dt><dd>{p.role}</dd></div>
        </dl>
      )}
      <div className="mt-auto pt-5 text-sm">
        {p.github
          ? <a href={p.github} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-white hover:text-cyan-400"><Github size={16} /> Repository <ExternalLink size={14} /></a>
          : <span className="text-slate-500">Repository link not available yet</span>}
      </div>
    </article>
  )
}

function Projects() {
  const cats = ['All', ...new Set(projects.map(p => p.category))]
  const [cat, setCat] = useState('All')
  return (
    <Section id="projects" kicker="Work" title="Featured Projects">
      <div className="mb-8 flex flex-wrap gap-2" role="group" aria-label="Filter projects">
        {cats.map(c => (
          <button key={c} onClick={() => setCat(c)} aria-pressed={cat === c}
            className={`rounded-full px-4 py-1.5 text-sm ${cat === c ? 'bg-cyan-400 font-semibold text-slate-900' : 'border border-white/15 text-slate-300 hover:bg-white/10'}`}>{c}</button>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.filter(p => cat === 'All' || p.category === cat).map(p => <ProjectCard key={p.id} p={p} />)}
      </div>
    </Section>
  )
}

function ContactForm() {
  const empty = { name: '', email: '', message: '', website: '' }
  const [f, setF] = useState(empty)
  const [errs, setErrs] = useState({})
  const [state, setState] = useState('idle')
  const set = k => e => setF({ ...f, [k]: e.target.value })
  const submit = async ev => {
    ev.preventDefault()
    const e = {}
    if (f.name.trim().length < 2) e.name = 'Please enter your name.'
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email)) e.email = 'Enter a valid email address.'
    if (f.message.trim().length < 10) e.message = 'Message should be at least 10 characters.'
    setErrs(e)
    if (Object.keys(e).length) return
    setState('sending')
    try {
      const r = await fetch(`${API}/api/contact`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) })
      if (!r.ok) throw new Error()
      setF(empty); setState('ok')
    } catch { setState('error') }
  }
  const field = (k, label, Tag = 'input', extra = {}) => (
    <div>
      <label htmlFor={k} className="mb-1 block text-sm text-slate-300">{label}</label>
      <Tag id={k} value={f[k]} onChange={set(k)} aria-invalid={!!errs[k]} {...extra}
        className="w-full rounded-xl border border-white/15 bg-white/5 px-4 py-3 text-white placeholder-slate-500" />
      {errs[k] && <p role="alert" className="mt-1 text-sm text-rose-400">{errs[k]}</p>}
    </div>
  )
  return (
    <form onSubmit={submit} noValidate className={`${card} space-y-4`}>
      {field('name', 'Name', 'input', { autoComplete: 'name' })}
      {field('email', 'Email', 'input', { type: 'email', autoComplete: 'email' })}
      {field('message', 'Message', 'textarea', { rows: 5 })}
      <input name="website" value={f.website} onChange={set('website')} tabIndex={-1} autoComplete="off" aria-hidden="true" className="absolute -left-[9999px]" />
      <button disabled={state === 'sending'} className={`${primary} disabled:opacity-60`}>{state === 'sending' ? 'Sending...' : 'Send message'}</button>
      {state === 'ok' && <p role="status" className="text-emerald-400">Thanks! Your message was sent.</p>}
      {state === 'error' && <p role="alert" className="text-rose-400">Could not send right now. Please email me directly at {profile.email}.</p>}
    </form>
  )
}

export default function App() {
  return (
    <>
      <a href="#about" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-white focus:p-2 focus:text-black">Skip to content</a>
      <Header />
      <main>
        <Hero />
        <Section id="about" kicker="About" title="About Me">
          <div className="max-w-3xl space-y-4 text-lg text-slate-300">{about.map(t => <p key={t}>{t}</p>)}</div>
        </Section>
        <Section id="experience" kicker="Experience" title="Professional Experience">
          {experience.map(e => (
            <article key={e.role} className={card}>
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="text-xl font-semibold text-white">{e.role} <span className="text-cyan-400">| {e.company}</span></h3>
                <p className="text-sm text-slate-400">{e.period} | {e.type}</p>
              </div>
              <ul className="mt-4 list-disc space-y-2 pl-5 text-slate-300">{e.points.map(x => <li key={x}>{x}</li>)}</ul>
            </article>
          ))}
        </Section>
        <Section id="skills" kicker="Skills" title="Technical Skills">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {skills.map(([cat, items]) => (
              <div key={cat} className={card}>
                <h3 className="font-semibold text-white">{cat}</h3>
                <div className="mt-3 flex flex-wrap gap-2">{items.map(s => <span key={s} className="rounded-lg bg-white/5 px-2.5 py-1 text-sm text-slate-200">{s}</span>)}</div>
              </div>
            ))}
          </div>
          <p className="mt-6 text-sm text-slate-400">{exposure}</p>
        </Section>
        <Projects />
        <Section id="education" kicker="Education" title="Education & Credentials">
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="space-y-4">
              {education.map(e => (
                <div key={e.school} className={card}>
                  <h3 className="font-semibold text-white">{e.school}</h3>
                  <p className="text-slate-300">{e.degree}</p>
                  <p className="mt-1 text-sm text-cyan-400">{e.detail}</p>
                </div>
              ))}
            </div>
            <div className={card}>
              <h3 className="flex items-center gap-2 font-semibold text-white"><Award size={18} className="text-cyan-400" /> Certifications</h3>
              <ul className="mt-3 space-y-2 text-slate-300">
                {certifications.map(c => <li key={c.title}>{c.link ? <a href={c.link} target="_blank" rel="noreferrer" className="hover:text-cyan-400">{c.title}</a> : c.title} <span className="text-slate-500">- {c.issuer}</span></li>)}
              </ul>
              <p className="mt-3 text-sm text-slate-400">{certNote}</p>
            </div>
          </div>
          <h3 className="mb-4 mt-12 text-xl font-semibold text-white">Activities & Volunteering</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {activities.map(a => (
              <div key={a.title + a.org} className={card}>
                <p className="font-semibold text-white">{a.title}</p>
                <p className="text-sm text-cyan-400">{a.org}</p>
                <p className="mt-1 text-sm text-slate-300">{a.note}</p>
              </div>
            ))}
          </div>
        </Section>
        <Section id="contact" kicker="Contact" title="Let's Talk">
          <div className="grid gap-8 lg:grid-cols-2">
            <div>
              <p className="max-w-md text-lg text-slate-300">I'm open to internships, graduate roles, collaborations, and conversations about data projects. Reach out and I'll reply as soon as I can.</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <a href={`mailto:${profile.email}`} className={primary}><Mail size={16} /> Email me</a>
                <a href={profile.linkedin} target="_blank" rel="noreferrer" className={ghost}><Linkedin size={16} /> LinkedIn</a>
                <a href={profile.github} target="_blank" rel="noreferrer" className={ghost}><Github size={16} /> GitHub</a>
              </div>
            </div>
            <ContactForm />
          </div>
        </Section>
      </main>
      <footer className="border-t border-white/10 py-8 text-sm text-slate-400">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5">
          <p>&copy; {new Date().getFullYear()} {profile.name}. Data science, analytics & applied AI.</p>
          <div className="flex flex-wrap gap-4">{nav.map(([l, id]) => <a key={id} href={`#${id}`} className="hover:text-white">{l}</a>)}</div>
        </div>
      </footer>
    </>
  )
}
