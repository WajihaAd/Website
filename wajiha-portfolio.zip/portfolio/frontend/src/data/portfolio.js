// Central content file. Edit here; no component changes needed.
export const profile = {
  name: 'Wajiha Adnan',
  headline: 'Turning Data Into Insights. Building Solutions That Matter.',
  intro:
    "I'm Wajiha Adnan, a Data Science student at NED University and former Data Science & Data Analytics Intern at MMP Pakistan. I work with data analytics, Power BI, Python, SQL, and applied AI to uncover insights and solve real-world problems.",
  email: 'wajihaadnan13@gmail.com',
  linkedin: 'https://www.linkedin.com/in/wajiha-adnan', // from resume - confirm
  github: 'https://github.com/WajihaAd',
  resume: '/resume.pdf', // replace frontend/public/resume.pdf to update
  location: 'Karachi, Pakistan',
}

export const nav = [['Home', 'home'], ['About', 'about'], ['Experience', 'experience'], ['Skills', 'skills'], ['Projects', 'projects'], ['Education', 'education'], ['Contact', 'contact']]

export const about = [
  "I'm a BS Computer Science student specializing in Data Science at NED University of Engineering & Technology, Karachi. My coursework and projects sit at the intersection of analytics, business intelligence, and machine learning.",
  'I enjoy turning messy, complex datasets into insights people can act on: clear dashboards, honest metrics, and practical data-driven applications. During my internship at MMP Pakistan I worked on recruitment analytics and an AI-assisted applicant tracking system, and I taught an internal Power BI session.',
  'I approach problems by breaking them into small steps, checking assumptions against the data, and explaining results in plain language. I am looking for internships and entry-level roles in data analytics, BI, and data science.',
]

export const experience = [
  {
    role: 'Data Science & Data Analytics Intern',
    company: 'MMP Pakistan',
    period: 'June 2026 - July 2026',
    type: 'Former intern',
    points: [
      'Contributed to an AI-powered Applicant Tracking System for resume screening and candidate ranking.',
      'Worked on resume evaluation workflows that compare CVs against job descriptions.',
      'Developed Power BI dashboards for candidate rankings and recruitment metrics.',
      'Explored duplicate CV detection and removal.',
      'Supported recruitment analytics and process optimization.',
      'Delivered an internal Power BI training seminar on dashboard design and data modeling.',
    ],
  },
]

export const skills = [
  ['Data Analytics & BI', ['Power BI', 'DAX', 'Power Query', 'Advanced Excel', 'Data Visualization', 'Data Modeling', 'Exploratory Data Analysis', 'KPI Reporting']],
  ['Programming & Data Processing', ['Python', 'Pandas', 'NumPy', 'Matplotlib', 'Seaborn', 'SQL']],
  ['Databases', ['PostgreSQL', 'MySQL', 'SQLite', 'SQL Server (SSMS)', 'Oracle SQL / PL-SQL']],
  ['Data Science & ML', ['Scikit-learn', 'Feature Engineering', 'Statistical Analysis', 'Predictive Analytics', 'Forecasting', 'Model Evaluation']],
  ['AI & NLP', ['RAG', 'LangChain', 'Hugging Face Embeddings', 'Sentence Transformers', 'FAISS', 'Gemini API', 'NLP']],
  ['Applications & Tools', ['Flask', 'Streamlit', 'HTML', 'CSS', 'JavaScript', 'Git', 'GitHub']],
]
export const exposure = 'Additional exposure: Snowflake, Databricks, Apache Spark, Kafka.'

export const education = [
  { school: 'NED University of Engineering & Technology, Karachi', degree: 'Bachelor of Science in Computer Science (Specialization in Data Science)', detail: 'CGPA: 3.87 / 4.00 | Final-year student' }, // TODO confirm CGPA (resume 3.87 vs prompt 3.89) and semester
  { school: 'COMMECS College, Karachi', degree: 'Intermediate (Pre-Engineering)', detail: 'Grade: A-1' },
  { school: 'The Metropolitan Academy, Karachi', degree: 'Matriculation', detail: 'Grade: A-1' },
]

// Add entries here as you gather them: { title, issuer, link? }
export const certifications = [
  { title: 'SQL (Full/Advanced Track)', issuer: 'DataCamp' },
  { title: 'Data Analysis with Python (Matplotlib)', issuer: 'DataCamp' },
  { title: 'Data Analysis Course', issuer: 'Ali Data' },
]
export const certNote = 'Additional certifications are listed on LinkedIn.'

export const activities = [
  { title: 'Section Leader (Volunteer)', org: 'Code in Place, Stanford University', note: 'Ongoing. Teaching international students in a virtual programming course and coaching problem-solving.' },
  { title: 'Volunteer', org: 'Elderly Care Program, EduCast', note: 'Coordinated meetings and supported weekly health check-ins.' },
  { title: 'Event Management Team Member', org: 'DataInsight Club, NED University', note: 'Helped plan and host data-focused club events.' },
  { title: 'Participant', org: 'Koderz Combat, NED University', note: 'Recurring semester coding competition.' },
  { title: 'Participant', org: 'Inter-University Power BI & Data Analytics Competitions', note: 'Dashboard development and analytical problem-solving.' },
  { title: 'BCG Data Science', org: 'Forage', note: 'Virtual job simulation (not employment).' },
]
