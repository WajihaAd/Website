# Project Handoff
**Project:** portfolio for Wajiha Adnan (React/Vite/Tailwind v4 + Flask). Spec: the user's master prompt (truthful content, no invented links/metrics, no admin dashboard).

## Done
Backend `/api/health`, `/api/projects`, `/api/contact`; frontend with nav, hero, about, experience, skills, filterable projects, education, certifications, activities, contact form, footer; SEO meta, favicon, resume PDF, README.

## Not done / untested
- `npm install`, `npm run build`, and the Flask server have NOT been run. Verify first and fix any errors.
- No project screenshots/thumbnails (hero has an SVG illustration only); no per-project detail pages (expandable details instead).
- JavaScript, not TypeScript. Dark theme only.
- Optional projects (HeatSafe, license plate recognition) deliberately omitted until confirmed.

## Open questions for the user
- CGPA: resume says 3.87, master prompt says 3.89 (site uses 3.87). Semester: "final-year" vs "7th semester".
- Oracle project is titled "Hospital Management System" but the supplied repo is named "Pharmacy-Mangament-system". Confirm.
- ATS repo (ATS_Pro-MMPakistan-): confirm it contains no confidential MMP code/data.
- LinkedIn URL taken from the resume; confirm.
