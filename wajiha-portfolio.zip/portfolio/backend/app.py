import json, os, re, time
from datetime import datetime, timezone
from pathlib import Path
from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_cors import CORS

load_dotenv()
BASE = Path(__file__).parent
PROJECTS = BASE.parent / "frontend" / "src" / "data" / "projects.json"  # single source of truth
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
HITS = {}  # simple in-memory rate limit: ip -> [timestamps]

app = Flask(__name__)
CORS(app, origins=os.getenv("ALLOWED_ORIGINS", "http://localhost:5173").split(","))


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/projects")
def projects():
    return jsonify(json.loads(PROJECTS.read_text(encoding="utf-8")))


@app.post("/api/contact")
def contact():
    ip, now = request.remote_addr or "?", time.time()
    HITS[ip] = [t for t in HITS.get(ip, []) if now - t < 3600]
    if len(HITS[ip]) >= 5:
        return {"error": "Too many messages. Please try again later."}, 429
    d = request.get_json(silent=True) or {}
    if d.get("website"):  # honeypot field: bots fill it, humans never see it
        return {"ok": True}
    name, email, msg = (str(d.get(k, "")).strip() for k in ("name", "email", "message"))
    errors = {}
    if not 2 <= len(name) <= 100: errors["name"] = "Name must be 2-100 characters."
    if not EMAIL_RE.match(email) or len(email) > 200: errors["email"] = "Enter a valid email."
    if not 10 <= len(msg) <= 3000: errors["message"] = "Message must be 10-3000 characters."
    if errors:
        return {"errors": errors}, 400
    HITS[ip].append(now)
    with open(BASE / "messages.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps({"at": datetime.now(timezone.utc).isoformat(), "name": name, "email": email, "message": msg}) + "\n")
    return {"ok": True}


if __name__ == "__main__":
    app.run(port=5000, debug=os.getenv("FLASK_DEBUG") == "1")
